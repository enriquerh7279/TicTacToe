package game;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * @author Enrique Ramirez-Holston
 */

public class Button extends JButton{

	int count;
	String text = "";
	int buttonNum;	
	boolean isAssigned = false;

	public Button() {}
	
	public void toggle(boolean isX, int turnCount) {
		count = turnCount;
		if (isAssigned) {
			return;
		}
		else {
			count++;
			isAssigned = true;
			if (isX) {
				text = "X";
				setText(text);
			} else {
				text = "O";
				setText(text);
			}
		}
		
	}
	
	public void resetButton() {
		count = 0;
		text = "";
		isAssigned = false;
		repaint();
	}
	
	public String getText() {
		return text;
	}

}