package game;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * @author Enrique Ramirez-Holston
 */
public class Board extends JFrame implements ActionListener{
	
	int turnCount = 0;
	boolean isPlayerX = true;
	boolean isGameActive = false;
	private Button[][] buttons;
	JFrame frame = new JFrame();

	public static void main(String[] args) {
		Board b = new Board();
		b.setVisible(true);
	} 
	public Board() {
		
		buttons = new Button[3][3];
		isGameActive = true;
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3, 3));
		
		/*Creates nine buttons and adds them to an array in the following configuration:
		 * 
		 * (0,0)	(0,1)	(0,2)
		 * (1,0)	(1,1)	(1,2)
		 * (2,0)	(2,1)	(2,2)
		 */
		for(int x = 0; x < 3; x++){
			for(int y = 0; y < 3; y++) {
			
			Button button = new Button();
			panel.add(button);
			button.addActionListener(this);
			button.setFont(new Font("Arial", Font.PLAIN, 40));
			buttons[x][y] = button;
		}
		}
		
		setTitle("Tic-Tac-Toe");
		setContentPane(panel);
		setPreferredSize(new Dimension(300, 300));
		pack();
	}
	
	public void actionPerformed(ActionEvent e) {
		
		Button button = (Button)e.getSource();
		
		if(button.isAssigned){ 
			JOptionPane.showMessageDialog(frame, "Please select a button that isn't already selected.", "Invalid Selection", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		button.toggle(isPlayerX, turnCount);
		turnCount = button.count;
		if (hasWon()) {
			if(isPlayerX) {
				setGameResult('X');
				return;
			} else {
				setGameResult('O');
				return;
			}
		
		} else {
			if(turnCount == 9) {
				setGameResult('N');
				return;
			}
		isPlayerX = !isPlayerX;
		}
	}

	public boolean hasWon() {
		if( turnCount < 5)	return false;
	
		if(this.checkVertical()) return true;
	
		if(this.checkHorizontal())	return true;
	
		if(this.checkDiagonals()) return true;
	
		return false;
	}
	
	//checks the current buttons vertical neighbors for a match.
	public boolean checkVertical() {
		for(int y = 0; y < 3; y++) {
			if (buttonsAreEqual(0,y,1,y,2,y)) return true;
			}
			return false;
	}
	
	//checks the current buttons horizontal neighbors for a match.
	public boolean checkHorizontal() {
		for(int x = 0; x < 3; x++) {
		if (buttonsAreEqual(x,0,x,1,x,2)) return true;
		}
		return false;
	}
	
	//checks the current buttons diagonal neighbors for a match.
	public boolean checkDiagonals() {
		if (buttonsAreEqual(0,0,1,1,2,2)) return true;
		if (buttonsAreEqual(2,0,1,1,0,2)) return true;
		return false;
	}
	
	public boolean buttonsAreEqual(int x1, int y1, int x2, int y2, int x3, int y3) {
		String button1Text = buttons[x1][y1].getText();
		String button2Text = buttons[x2][y2].getText();
		String button3Text = buttons[x3][y3].getText();
		if((button1Text.equals(button2Text) & button2Text.equals(button3Text)) & !button1Text.equals("") ) {
			return true;
			} else return false;
	}
	
	//sets a dialog box to appear showing the end of the game
	public void setGameResult(char c) {
		isGameActive = false;
		int n = 0;
		if( c == 'X') n = JOptionPane.showConfirmDialog(frame, "Would you like to play again?", "Player X has won the game!", JOptionPane.YES_NO_OPTION);
			
		if( c == 'O') n = JOptionPane.showConfirmDialog(frame, "Would you like to play again?", "Player O has won the game!", JOptionPane.YES_NO_OPTION);
			
		if( c == 'N') n = JOptionPane.showConfirmDialog(frame, "Would you like to play again?", "There has been a tie!", JOptionPane.YES_NO_OPTION);
		
		determineChoice(n);
	}
	
	public void determineChoice(int n) {
		if(n == JOptionPane.YES_OPTION) resetBoard();
		
		if(n == JOptionPane.NO_OPTION) {
			dispose();
			System.exit(0);
		}
	}
	
	public void resetBoard() {
		for(int x = 0; x < 3; x++){
			for(int y = 0; y < 3; y++) {
				buttons[x][y].resetButton();
			}
		}
		turnCount = 0;
		isPlayerX = true;
		isGameActive = true;
		return;
	}
}
